import { makeStyles } from "@material-ui/core";

export const useStyle = makeStyles((theme) => ({
  root: {},

  titleBox: {
    textAlign: "center",
    fontSize: "16px",
    color: "#666666",
    textTransform: "uppercase",
    marginTop: "20px",
  },
}));
