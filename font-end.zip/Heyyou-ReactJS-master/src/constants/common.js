export const sliderImg = [
  "https://goyacdn.everthemes.com/demo-fashion/wp-content/uploads/sites/3/2020/02/curly_hair_girl-1.jpg",
  "https://goyacdn.everthemes.com/demo-fashion/wp-content/uploads/sites/3/2020/02/monigote.jpg",
  "https://goyacdn.everthemes.com/demo-fashion/wp-content/uploads/sites/3/2020/02/curly_hair_white-1.jpg",
];

export const bannerImg = [
  "https://theme.hstatic.net/200000031420/1000719377/14/xxx_4.jpg?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/xxx_5.jpg?v=154",
];

export const brandImg = [
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_5.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_1.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_2.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_3.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_4.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_5.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_1.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_2.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_3.png?v=154",
  "https://theme.hstatic.net/200000031420/1000719377/14/home_brand_logo_4.png?v=154",
];
