const StorageKeys = {
  USER: "user",
  TOKEN: "access_token",
};

export default StorageKeys;
