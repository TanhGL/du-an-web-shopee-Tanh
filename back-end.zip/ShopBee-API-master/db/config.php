<?php
define('HOST', '127.0.0.1:3308');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'shopbee');