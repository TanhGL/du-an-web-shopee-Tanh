<?php
error_reporting(E_ALL);

$MY_SECRET_KEY = "j4CIr4tjww1ZYrxoWrXyPuxVGSdzX9KBbpxC3cUsK1H3tVFfgeXoK";